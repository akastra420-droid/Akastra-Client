#pragma once
#include <filesystem>
#include <fstream>
#include <string>
#include <system_error>

namespace akastra {

// Folder the game process is allowed to write to:
//   /storage/emulated/0/Android/data/<package>/files/Akastra
// The package name is read from the running process, so this works for any
// Minecraft package name.
inline const std::filesystem::path& dataDir() {
    static const std::filesystem::path dir = [] {
        std::string pkg;
        {
            std::ifstream f("/proc/self/cmdline");
            std::getline(f, pkg, '\0');
        }
        if (pkg.empty()) pkg = "com.mojang.minecraftpe";
        std::filesystem::path d =
            std::filesystem::path("/storage/emulated/0/Android/data") / pkg / "files" / "Akastra";
        std::error_code ec;
        std::filesystem::create_directories(d, ec);
        return d;
    }();
    return dir;
}

} // namespace akastra
