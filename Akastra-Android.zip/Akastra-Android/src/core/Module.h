#pragma once
#include <string>
#include <utility>

namespace akastra {

// Base class for every feature (FPS counter, CPS, keystrokes, ...).
class Module {
public:
    Module(std::string name, std::string description, int defaultKey = 0)
        : name_(std::move(name)), description_(std::move(description)), key_(defaultKey) {}
    virtual ~Module() = default;

    const std::string& name() const { return name_; }
    const std::string& description() const { return description_; }

    bool enabled() const { return enabled_; }
    void setEnabled(bool v) {
        if (v == enabled_) return;
        enabled_ = v;
        v ? onEnable() : onDisable();
    }
    void toggle() { setEnabled(!enabled_); }

    int key() const { return key_; }
    void setKey(int k) { key_ = k; }

    // HUD position (screen pixels)
    float x = 10.f, y = 10.f;

    virtual void onEnable() {}
    virtual void onDisable() {}
    virtual void onTick() {}      // once per game tick
    virtual void onRender() {}    // once per frame, draw HUD here
    virtual void onKey(int /*vk*/, bool /*down*/) {}
    virtual void onMouse(int /*button*/, bool /*down*/) {}

    // Create this module's signature hooks (see hooks::hookSignature).
    // Called once, before hooks are enabled.
    virtual void installHooks() {}
    // Extra ImGui widgets for this module's settings, shown in the menu.
    virtual void drawSettings() {}

private:
    std::string name_, description_;
    bool enabled_ = false;
    int key_ = 0;
};

} // namespace akastra
