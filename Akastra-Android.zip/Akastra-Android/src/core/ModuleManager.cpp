#include "core/ModuleManager.h"
#include "core/Config.h"
#include "modules/WatermarkModule.h"
#include "modules/FpsModule.h"
#include "modules/CpsModule.h"
#include "modules/ClockModule.h"
#include "modules/SessionTimerModule.h"
#include "modules/FrameTimeModule.h"
#include "modules/MemoryModule.h"
#include "modules/CrosshairModule.h"
#include "modules/DateModule.h"
#include "modules/BatteryModule.h"
#include "modules/CpuModule.h"
#include "modules/CustomTextModule.h"
#include "modules/StatsModules.h"
#include "modules/TimerModules.h"
#include "modules/OverlayModules.h"
#include "modules/NotesModule.h"
#include "modules/PingModule.h"
#include <imgui.h>
#include <algorithm>

namespace akastra {

ModuleManager& ModuleManager::get() {
    static ModuleManager inst;
    return inst;
}

void ModuleManager::registerAll() {
    modules_.push_back(std::make_unique<WatermarkModule>());
    modules_.push_back(std::make_unique<FpsModule>());
    modules_.push_back(std::make_unique<CpsModule>());
    modules_.push_back(std::make_unique<ClockModule>());
    modules_.push_back(std::make_unique<SessionTimerModule>());
    modules_.push_back(std::make_unique<FrameTimeModule>());
    modules_.push_back(std::make_unique<MemoryModule>());
    modules_.push_back(std::make_unique<CrosshairModule>());
    modules_.push_back(std::make_unique<DateModule>());
    modules_.push_back(std::make_unique<BatteryModule>());
    modules_.push_back(std::make_unique<CpuModule>());
    modules_.push_back(std::make_unique<CustomTextModule>());
    modules_.push_back(std::make_unique<FpsStatsModule>());
    modules_.push_back(std::make_unique<FpsGraphModule>());
    modules_.push_back(std::make_unique<TapCounterModule>());
    modules_.push_back(std::make_unique<FreeRamModule>());
    modules_.push_back(std::make_unique<StorageModule>());
    modules_.push_back(std::make_unique<BatteryTempModule>());
    modules_.push_back(std::make_unique<DeviceUptimeModule>());
    modules_.push_back(std::make_unique<StopwatchModule>());
    modules_.push_back(std::make_unique<BreakReminderModule>());
    modules_.push_back(std::make_unique<ScreenTintModule>());
    modules_.push_back(std::make_unique<VignetteModule>());
    modules_.push_back(std::make_unique<LetterboxModule>());
    modules_.push_back(std::make_unique<GridModule>());
    modules_.push_back(std::make_unique<ScreenBorderModule>());
    modules_.push_back(std::make_unique<AnalogClockModule>());
    modules_.push_back(std::make_unique<NotesModule>());
    modules_.push_back(std::make_unique<PingModule>());
    Config::get().load(modules_);
}

void ModuleManager::installHooks() {
    for (auto& m : modules_) m->installHooks();
}

void ModuleManager::tick() {
    for (auto& m : modules_) if (m->enabled()) m->onTick();
}

// ---------------------------------------------------------------------------
// Touch input
// ---------------------------------------------------------------------------
void ModuleManager::pushTouch(const TouchEvt& e) {
    std::lock_guard<std::mutex> lk(touchMu_);
    if (touchQ_.size() < 256) touchQ_.push_back(e);   // never grow without bound
}

bool ModuleManager::overUi(float x, float y) {
    std::lock_guard<std::mutex> lk(rectMu_);
    return x >= btn_.x && x <= btn_.x + btn_.w && y >= btn_.y && y <= btn_.y + btn_.h;
}

// Turns queued touches into ImGui input and module clicks. Runs on the render
// thread, so ImGui and the modules are only ever touched from one thread.
void ModuleManager::pumpInput() {
    std::vector<TouchEvt> evts;
    {
        std::lock_guard<std::mutex> lk(touchMu_);
        evts.swap(touchQ_);
    }

    ImGuiIO& io = ImGui::GetIO();
    for (const auto& e : evts) {
        io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen);
        io.AddMousePosEvent(e.x, e.y);
        if (e.kind == TouchKind::Down) io.AddMouseButtonEvent(0, true);
        if (e.kind == TouchKind::Up)   io.AddMouseButtonEvent(0, false);

        if (!e.captured && e.kind != TouchKind::Move) {
            const bool down = (e.kind == TouchKind::Down);
            for (auto& m : modules_) if (m->enabled()) m->onMouse(0, down);   // CPS counts taps
        }
    }
}

// ---------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------
void ModuleManager::render() {
    for (auto& m : modules_) if (m->enabled()) m->onRender();

    drawButton();

    const bool wasOpen = menuOpen;
    if (wasOpen) drawMenu();
    if (wasOpen && !menuOpen) Config::get().save(modules_);
}

// Small floating button on the left edge. Tap it to open/close the menu.
void ModuleManager::drawButton() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos({8.f, ds.y * 0.45f});
    ImGui::SetNextWindowBgAlpha(0.55f);

    const ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoFocusOnAppearing |
        ImGuiWindowFlags_NoNav;

    if (ImGui::Begin("##akastra_btn", nullptr, flags)) {
        if (ImGui::Button(menuOpen ? "X" : "A", {44.f, 44.f})) menuOpen = !menuOpen;

        ImVec2 p = ImGui::GetWindowPos(), s = ImGui::GetWindowSize();
        std::lock_guard<std::mutex> lk(rectMu_);
        btn_ = {p.x, p.y, s.x, s.y};
    }
    ImGui::End();
}

void ModuleManager::drawMenu() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos({ds.x * 0.5f, ds.y * 0.5f}, ImGuiCond_Appearing, {0.5f, 0.5f});
    ImGui::SetNextWindowSize({std::min(ds.x * 0.85f, 460.f), ds.y * 0.8f}, ImGuiCond_Appearing);

    bool open = true;
    if (ImGui::Begin("Akastra", &open, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings)) {
        ImGui::TextDisabled("Tap A or X to close. Drag to scroll.");
        ImGui::Separator();

        // Finger-drag scrolling (ImGui only scrolls by wheel/scrollbar by default).
        if (ImGui::IsWindowHovered() && ImGui::IsMouseDragging(0, 6.f) && !ImGui::IsAnyItemActive())
            ImGui::SetScrollY(ImGui::GetScrollY() - ImGui::GetIO().MouseDelta.y);

        for (auto& m : modules_) {
            ImGui::PushID(m.get());

            bool en = m->enabled();
            if (ImGui::Checkbox(m->name().c_str(), &en)) m->setEnabled(en);

            ImGui::Indent();
            ImGui::SetNextItemWidth(80.f);
            ImGui::DragFloat("##x", &m->x, 1.f, -2000.f, 4000.f, "x %.0f");
            ImGui::SameLine();
            ImGui::SetNextItemWidth(80.f);
            ImGui::DragFloat("##y", &m->y, 1.f, -2000.f, 4000.f, "y %.0f");
            ImGui::SameLine();
            ImGui::TextDisabled("position");
            m->drawSettings();
            ImGui::Unindent();

            ImGui::PopID();
        }
    }
    ImGui::End();
    menuOpen = open;
}

Module* ModuleManager::find(const std::string& name) {
    for (auto& m : modules_) if (m->name() == name) return m.get();
    return nullptr;
}

} // namespace akastra
