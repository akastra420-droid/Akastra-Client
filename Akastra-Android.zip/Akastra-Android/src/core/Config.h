#pragma once
#include <memory>
#include <vector>
#include "core/Module.h"

namespace akastra {

// Saves/loads module state (enabled, key, position) to %APPDATA%\Akastra\config.json
class Config {
public:
    static Config& get();
    void load(std::vector<std::unique_ptr<Module>>& modules);
    void save(const std::vector<std::unique_ptr<Module>>& modules);
};

} // namespace akastra
