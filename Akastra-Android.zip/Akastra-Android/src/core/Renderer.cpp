#include "core/Renderer.h"

#include <imgui.h>
#include <imgui_impl_opengl3.h>

#include <sys/stat.h>
#include <algorithm>
#include <cfloat>
#include <chrono>

namespace akastra {

namespace {
std::chrono::steady_clock::time_point g_last;

// 0xAARRGGBB -> ImGui's 0xAABBGGRR
ImU32 toIm(uint32_t argb) {
    return IM_COL32((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF, (argb >> 24) & 0xFF);
}
} // namespace

Renderer& Renderer::get() {
    static Renderer inst;
    return inst;
}

bool Renderer::init(int /*w*/, int h) {
    if (ready_) return true;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;

    // Phones are far denser than monitors. Everything is laid out in logical
    // pixels and scaled up: a 1080px-tall screen gives scale 2.0.
    scale_ = std::clamp(static_cast<float>(h) / 540.f, 1.5f, 4.f);

    ImGui::StyleColorsDark();
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 8.f;
    st.FrameRounding = 6.f;
    st.WindowPadding = {12.f, 12.f};
    st.FramePadding = {10.f, 8.f};   // big enough for fingers
    st.ItemSpacing = {10.f, 10.f};
    st.ScrollbarSize = 18.f;
    st.GrabMinSize = 22.f;

    // Akastra light-gold theme (colors only; sizes above are unchanged).
    {
        auto gold = [](float a) { return ImVec4(0.91f, 0.83f, 0.54f, a); };      // light gold
        auto dark = [](float a) { return ImVec4(0.10f, 0.09f, 0.06f, a); };      // warm near-black
        ImVec4* c = st.Colors;
        c[ImGuiCol_WindowBg]         = dark(0.92f);
        c[ImGuiCol_PopupBg]          = dark(0.96f);
        c[ImGuiCol_TitleBg]          = ImVec4(0.20f, 0.17f, 0.09f, 1.f);
        c[ImGuiCol_TitleBgActive]    = ImVec4(0.32f, 0.27f, 0.13f, 1.f);
        c[ImGuiCol_Border]           = gold(0.35f);
        c[ImGuiCol_Text]             = ImVec4(0.96f, 0.91f, 0.74f, 1.f);
        c[ImGuiCol_TextDisabled]     = gold(0.50f);
        c[ImGuiCol_FrameBg]          = ImVec4(0.22f, 0.19f, 0.10f, 0.80f);
        c[ImGuiCol_FrameBgHovered]   = ImVec4(0.32f, 0.27f, 0.13f, 0.90f);
        c[ImGuiCol_FrameBgActive]    = ImVec4(0.42f, 0.35f, 0.17f, 1.f);
        c[ImGuiCol_CheckMark]        = gold(1.f);
        c[ImGuiCol_SliderGrab]       = gold(0.85f);
        c[ImGuiCol_SliderGrabActive] = gold(1.f);
        c[ImGuiCol_Button]           = ImVec4(0.91f, 0.83f, 0.54f, 0.30f);
        c[ImGuiCol_ButtonHovered]    = ImVec4(0.91f, 0.83f, 0.54f, 0.50f);
        c[ImGuiCol_ButtonActive]     = ImVec4(0.91f, 0.83f, 0.54f, 0.70f);
        c[ImGuiCol_Header]           = ImVec4(0.91f, 0.83f, 0.54f, 0.30f);
        c[ImGuiCol_HeaderHovered]    = ImVec4(0.91f, 0.83f, 0.54f, 0.45f);
        c[ImGuiCol_HeaderActive]     = ImVec4(0.91f, 0.83f, 0.54f, 0.60f);
        c[ImGuiCol_Separator]        = gold(0.30f);
        c[ImGuiCol_ScrollbarBg]      = dark(0.50f);
        c[ImGuiCol_ScrollbarGrab]    = gold(0.50f);
        c[ImGuiCol_ScrollbarGrabHovered] = gold(0.70f);
        c[ImGuiCol_ScrollbarGrabActive]  = gold(0.90f);
    }

    // Rasterise the font at the real pixel size, then scale it back down so it
    // stays sharp at logical size.
    const float fontPx = 16.f * scale_;
    ImFont* font = nullptr;
    struct stat sb;
    const char* roboto = "/system/fonts/Roboto-Regular.ttf";
    if (stat(roboto, &sb) == 0) font = io.Fonts->AddFontFromFileTTF(roboto, fontPx);
    if (!font) {
        ImFontConfig cfg;
        cfg.SizePixels = fontPx;
        io.Fonts->AddFontDefault(&cfg);
    }
    io.FontGlobalScale = 1.f / scale_;
    io.DisplayFramebufferScale = {scale_, scale_};

    if (!ImGui_ImplOpenGL3_Init("#version 300 es")) {
        ImGui::DestroyContext();
        err_ = "ImGui_ImplOpenGL3_Init failed";
        return false;
    }

    g_last = std::chrono::steady_clock::now();
    ready_ = true;
    return true;
}

void Renderer::beginFrame(int w, int h) {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = {w / scale_, h / scale_};

    auto now = std::chrono::steady_clock::now();
    float dt = std::chrono::duration<float>(now - g_last).count();
    g_last = now;
    io.DeltaTime = std::clamp(dt, 1.f / 1000.f, 0.1f);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
}

void Renderer::endFrame() {
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

void Renderer::fillRect(float x, float y, float w, float h, uint32_t argb) {
    if (!ready_) return;
    ImGui::GetBackgroundDrawList()->AddRectFilled({x, y}, {x + w, y + h}, toIm(argb), 3.f);
}

void Renderer::text(const std::string& s, float x, float y, uint32_t argb, float size) {
    if (!ready_) return;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImFont* f = ImGui::GetFont();
    dl->AddText(f, size, {x + 1.f, y + 1.f}, IM_COL32(0, 0, 0, 160), s.c_str());  // shadow
    if (argb == 0xFFFFFFFFu) argb = 0xFFF5E8BDu;   // default white HUD text -> light gold
    dl->AddText(f, size, {x, y}, toIm(argb), s.c_str());
}

float Renderer::textWidth(const std::string& s, float size) const {
    if (!ready_) return s.size() * size * 0.5f;
    return ImGui::GetFont()->CalcTextSizeA(size, FLT_MAX, 0.f, s.c_str()).x;
}

} // namespace akastra
