#pragma once
#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
#include "core/Module.h"

namespace akastra {

enum class TouchKind { Move, Down, Up };

struct TouchEvt {
    TouchKind kind;
    float x, y;        // logical pixels
    bool captured;     // true if Akastra's UI owns this touch (not passed to the game)
};

class ModuleManager {
public:
    static ModuleManager& get();

    void registerAll();
    void installHooks();
    void tick();

    // --- touch input -------------------------------------------------------
    // pushTouch() may be called from the game's input thread. Everything else
    // runs on the render thread, so modules never need their own locking.
    void pushTouch(const TouchEvt& e);
    void pumpInput();                    // render thread, before Renderer::beginFrame()
    bool overUi(float x, float y);       // is this point on the Akastra button?

    // --- drawing (render thread, between beginFrame/endFrame) --------------
    void render();

    Module* find(const std::string& name);
    const std::vector<std::unique_ptr<Module>>& modules() const { return modules_; }

    std::atomic<bool> menuOpen{false};

private:
    void drawButton();
    void drawMenu();

    struct Rect { float x = 0, y = 0, w = 0, h = 0; };

    std::vector<std::unique_ptr<Module>> modules_;
    std::mutex touchMu_;
    std::vector<TouchEvt> touchQ_;
    std::mutex rectMu_;
    Rect btn_;
};

} // namespace akastra
