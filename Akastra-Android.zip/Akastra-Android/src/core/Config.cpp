#include "core/Config.h"
#include "core/Paths.h"
#include <nlohmann/json.hpp>
#include <fstream>

namespace akastra {

Config& Config::get() {
    static Config inst;
    return inst;
}

void Config::load(std::vector<std::unique_ptr<Module>>& modules) {
    std::ifstream f(dataDir() / "config.json");
    if (!f) return;
    nlohmann::json j = nlohmann::json::parse(f, nullptr, false);
    if (j.is_discarded()) return;
    for (auto& m : modules) {
        if (!j.contains(m->name())) continue;
        auto& e = j[m->name()];
        m->setEnabled(e.value("enabled", false));
        m->x = e.value("x", m->x);
        m->y = e.value("y", m->y);
    }
}

void Config::save(const std::vector<std::unique_ptr<Module>>& modules) {
    nlohmann::json j;
    for (auto& m : modules)
        j[m->name()] = {{"enabled", m->enabled()}, {"x", m->x}, {"y", m->y}};
    std::ofstream(dataDir() / "config.json") << j.dump(2);
}

} // namespace akastra
