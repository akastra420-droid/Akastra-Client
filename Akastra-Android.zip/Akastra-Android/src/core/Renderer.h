#pragma once
#include <cstdint>
#include <string>

namespace akastra {

// Drawing facade backed by Dear ImGui (OpenGL ES 3).
//
// All coordinates are LOGICAL pixels. The renderer scales them up to the
// phone's real resolution (scale()), so a module drawn at x=10 looks about the
// same size on any phone. Colors are 0xAARRGGBB.
class Renderer {
public:
    static Renderer& get();

    // Call on the render thread with the GL context current.
    bool init(int widthPx, int heightPx);
    bool ready() const { return ready_; }
    const std::string& lastError() const { return err_; }
    float scale() const { return scale_; }

    void beginFrame(int widthPx, int heightPx);
    void endFrame();

    void fillRect(float x, float y, float w, float h, uint32_t argb);
    void text(const std::string& s, float x, float y, uint32_t argb, float size = 16.f);
    float textWidth(const std::string& s, float size = 16.f) const;

private:
    bool ready_ = false;
    float scale_ = 1.f;
    std::string err_;
};

} // namespace akastra
