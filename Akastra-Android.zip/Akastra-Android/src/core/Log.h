#pragma once
#include <android/log.h>
#include <fstream>
#include <string>
#include "core/Paths.h"

namespace akastra {

// Writes to logcat (tag "Akastra") and to <dataDir>/akastra.log.
inline void log(const std::string& msg) {
    __android_log_write(ANDROID_LOG_INFO, "Akastra", msg.c_str());
    std::ofstream(dataDir() / "akastra.log", std::ios::app) << msg << "\n";
}

} // namespace akastra
