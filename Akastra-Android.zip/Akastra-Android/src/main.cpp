#include "core/Log.h"
#include "core/ModuleManager.h"
#include "hooks/Hooks.h"
#include <thread>

// Runs automatically when the game loads libakastra.so.
__attribute__((constructor)) static void akastraEntry() {
    std::thread([] {
        akastra::log("Akastra loaded.");
        akastra::ModuleManager::get().registerAll();
        if (!akastra::hooks::install())
            akastra::log("Hook install failed; Akastra is inactive.");
    }).detach();
}
