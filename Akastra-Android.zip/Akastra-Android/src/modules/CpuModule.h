#pragma once
#include "core/Module.h"
#include <chrono>

namespace akastra {

// Shows how much CPU the game process is using (100% = one full core).
class CpuModule : public Module {
public:
    CpuModule() : Module("CPU", "CPU used by the game") { x = 140.f; y = 186.f; }
    void onRender() override;

private:
    std::chrono::steady_clock::time_point last_{};
    long lastTicks_ = 0;
    double percent_ = 0.0;
};

} // namespace akastra
