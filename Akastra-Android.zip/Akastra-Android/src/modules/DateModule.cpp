#include "modules/DateModule.h"
#include "core/Renderer.h"
#include <imgui.h>
#include <ctime>
#include <cstdio>

namespace akastra {

void DateModule::onRender() {
    std::time_t t = std::time(nullptr);
    std::tm lt{};
    localtime_r(&t, &lt);

    char buf[32];
    if (dayFirst_) std::snprintf(buf, sizeof(buf), "%02d/%02d/%04d", lt.tm_mday, lt.tm_mon + 1, lt.tm_year + 1900);
    else           std::snprintf(buf, sizeof(buf), "%04d-%02d-%02d", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday);
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

void DateModule::drawSettings() {
    ImGui::Checkbox("day first (DD/MM/YYYY)", &dayFirst_);
}

} // namespace akastra
