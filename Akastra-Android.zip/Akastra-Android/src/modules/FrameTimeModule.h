#pragma once
#include "core/Module.h"
#include <chrono>

namespace akastra {

// Shows how long each frame takes, in milliseconds (smoothed).
class FrameTimeModule : public Module {
public:
    FrameTimeModule() : Module("Frame Time", "Milliseconds per frame") { x = 140.f; y = 76.f; }
    void onRender() override;

private:
    std::chrono::steady_clock::time_point last_{};
    float avgMs_ = 0.f;
};

} // namespace akastra
