#pragma once
#include "core/Module.h"
#include <chrono>

namespace akastra {

// Shows how much RAM the game process is using.
class MemoryModule : public Module {
public:
    MemoryModule() : Module("Memory", "RAM used by the game") { x = 140.f; y = 96.f; }
    void onRender() override;

private:
    std::chrono::steady_clock::time_point last_{};
    double mb_ = 0.0;
};

} // namespace akastra
