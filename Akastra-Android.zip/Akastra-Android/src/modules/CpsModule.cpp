#include "modules/CpsModule.h"
#include "core/Renderer.h"

namespace akastra {

void CpsModule::prune(std::deque<Clock::time_point>& d) {
    auto cutoff = Clock::now() - std::chrono::seconds(1);
    while (!d.empty() && d.front() < cutoff) d.pop_front();
}

void CpsModule::onMouse(int button, bool down) {
    if (!down) return;
    (button == 0 ? left_ : right_).push_back(Clock::now());
}

void CpsModule::onRender() {
    prune(left_);
    prune(right_);
    Renderer::get().text("CPS: " + std::to_string(left_.size()) + " | " + std::to_string(right_.size()),
                         x, y, 0xFFFFFFFF);
}

} // namespace akastra
