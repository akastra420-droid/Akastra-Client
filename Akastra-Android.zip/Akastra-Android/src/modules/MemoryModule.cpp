#include "modules/MemoryModule.h"
#include "core/Renderer.h"
#include <cstdio>
#include <unistd.h>

namespace akastra {

void MemoryModule::onRender() {
    // Refresh once per second.
    auto now = std::chrono::steady_clock::now();
    if (now - last_ >= std::chrono::seconds(1)) {
        last_ = now;
        long totalPages = 0, residentPages = 0;
        if (FILE* f = std::fopen("/proc/self/statm", "r")) {
            if (std::fscanf(f, "%ld %ld", &totalPages, &residentPages) == 2)
                mb_ = static_cast<double>(residentPages) * sysconf(_SC_PAGESIZE) / (1024.0 * 1024.0);
            std::fclose(f);
        }
    }

    char buf[32];
    std::snprintf(buf, sizeof(buf), "RAM: %.0f MB", mb_);
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

} // namespace akastra
