#pragma once
#include "core/Module.h"

namespace akastra {

// Shows the current local time.
class ClockModule : public Module {
public:
    ClockModule() : Module("Clock", "Shows the current local time") { x = 120.f; y = 36.f; }
    void onRender() override;
    void drawSettings() override;

private:
    bool use24h_ = false;
    bool showSeconds_ = false;
};

} // namespace akastra
