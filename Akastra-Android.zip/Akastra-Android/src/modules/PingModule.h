#pragma once
#include "core/Module.h"
#include <atomic>
#include <mutex>
#include <string>
#include <thread>

namespace akastra {

// Shows ping and player count of a Bedrock server you type into the menu.
// It sends a standard Bedrock server-list ping (UDP) every couple of seconds
// from a background thread, so it never slows down drawing.
class PingModule : public Module {
public:
    PingModule();
    ~PingModule() override;
    void onEnable() override;
    void onDisable() override;
    void onRender() override;
    void drawSettings() override;

private:
    void start();
    void stop();
    void workerLoop();
    void saveSettings();

    std::thread worker_;
    std::atomic<bool> run_{false};
    std::mutex mu_;
    std::string host_;
    int port_ = 19132;
    std::atomic<int> pingMs_{-1}, players_{-1}, maxPlayers_{-1};
    char hostBuf_[64] = {};
};

} // namespace akastra
