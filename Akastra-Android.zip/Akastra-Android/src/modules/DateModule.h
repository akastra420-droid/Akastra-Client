#pragma once
#include "core/Module.h"

namespace akastra {

// Shows today's date.
class DateModule : public Module {
public:
    DateModule() : Module("Date", "Shows today's date") { x = 120.f; y = 126.f; }
    void onRender() override;
    void drawSettings() override;

private:
    bool dayFirst_ = true;   // 11/11/2026 vs 2026-11-11 style toggle
};

} // namespace akastra
