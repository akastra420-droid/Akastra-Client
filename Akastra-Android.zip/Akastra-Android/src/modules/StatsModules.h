#pragma once
#include "core/Module.h"
#include <chrono>
#include <vector>

namespace akastra {

// Average / lowest / highest FPS over the last 10 seconds.
class FpsStatsModule : public Module {
public:
    FpsStatsModule() : Module("FPS Stats", "Average, min and max FPS (last 10 s)") { x = 240.f; y = 10.f; }
    void onRender() override;
private:
    std::chrono::steady_clock::time_point last_{};
    int frames_ = 0;
    std::vector<int> history_;
};

// Small bar graph of the last frame times. Tall or red bars are slow frames.
class FpsGraphModule : public Module {
public:
    FpsGraphModule() : Module("FPS Graph", "Frame time graph") { x = 240.f; y = 40.f; }
    void onRender() override;
private:
    static constexpr int kSamples = 90;
    float ms_[kSamples] = {};
    int head_ = 0;
    std::chrono::steady_clock::time_point last_{};
};

// Counts every tap on the game screen.
class TapCounterModule : public Module {
public:
    TapCounterModule() : Module("Tap Counter", "Total taps this session") { x = 240.f; y = 96.f; }
    void onMouse(int button, bool down) override { if (button == 0 && down) ++taps_; }
    void onRender() override;
    void drawSettings() override;
private:
    long long taps_ = 0;
};

// Free / total system RAM.
class FreeRamModule : public Module {
public:
    FreeRamModule() : Module("Free RAM", "Free and total phone RAM") { x = 240.f; y = 126.f; }
    void onRender() override;
private:
    std::chrono::steady_clock::time_point last_{};
    double freeGb_ = -1.0, totalGb_ = -1.0;
};

// Free storage on the phone.
class StorageModule : public Module {
public:
    StorageModule() : Module("Storage", "Free phone storage") { x = 240.f; y = 156.f; }
    void onRender() override;
private:
    std::chrono::steady_clock::time_point last_{};
    double freeGb_ = -1.0;
};

// Battery temperature.
class BatteryTempModule : public Module {
public:
    BatteryTempModule() : Module("Battery Temp", "Phone battery temperature") { x = 240.f; y = 186.f; }
    void onRender() override;
private:
    std::chrono::steady_clock::time_point last_{};
    double celsius_ = -1000.0;
};

// How long the phone has been on.
class DeviceUptimeModule : public Module {
public:
    DeviceUptimeModule() : Module("Device Uptime", "Time since the phone booted") { x = 240.f; y = 216.f; }
    void onRender() override;
private:
    std::chrono::steady_clock::time_point last_{};
    long long secs_ = -1;
};

} // namespace akastra
