#pragma once
#include "core/Module.h"

namespace akastra {

// Full-screen colour wash. Light gold by default and very faint.
class ScreenTintModule : public Module {
public:
    ScreenTintModule() : Module("Screen Tint", "Faint colour wash over the whole screen") {}
    void onRender() override;
    void drawSettings() override;
private:
    float rgb_[3] = {0.91f, 0.83f, 0.54f};
    float alpha_ = 0.06f;
};

// Darkens the screen edges.
class VignetteModule : public Module {
public:
    VignetteModule() : Module("Vignette", "Darkened screen edges") {}
    void onRender() override;
    void drawSettings() override;
private:
    float strength_ = 0.45f;
    float size_ = 0.18f;     // fraction of the screen height
};

// Black bars at the top and bottom for a cinematic look.
class LetterboxModule : public Module {
public:
    LetterboxModule() : Module("Letterbox", "Cinematic black bars") {}
    void onRender() override;
    void drawSettings() override;
private:
    float amount_ = 0.08f;   // each bar's height as a fraction of the screen
};

// Rule-of-thirds guide lines, useful for taking screenshots.
class GridModule : public Module {
public:
    GridModule() : Module("Grid", "Rule-of-thirds guide lines") {}
    void onRender() override;
    void drawSettings() override;
private:
    bool centre_ = false;
};

// Thin coloured frame around the screen.
class ScreenBorderModule : public Module {
public:
    ScreenBorderModule() : Module("Screen Border", "Colour frame around the screen") {}
    void onRender() override;
    void drawSettings() override;
private:
    float rgb_[3] = {0.91f, 0.83f, 0.54f};
    float thickness_ = 3.f;
};

// Analogue clock. x/y is its top-left corner.
class AnalogClockModule : public Module {
public:
    AnalogClockModule() : Module("Analog Clock", "Round clock face") { x = 360.f; y = 70.f; }
    void onRender() override;
    void drawSettings() override;
private:
    float radius_ = 36.f;
};

} // namespace akastra
