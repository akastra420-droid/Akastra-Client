#include "modules/CpuModule.h"
#include "core/Renderer.h"
#include <cstdio>
#include <cstring>
#include <unistd.h>

namespace akastra {

// utime + stime of this process, in clock ticks (0 if unreadable).
static long processTicks() {
    char buf[1024] = {};
    FILE* f = std::fopen("/proc/self/stat", "r");
    if (!f) return 0;
    size_t n = std::fread(buf, 1, sizeof(buf) - 1, f);
    std::fclose(f);
    buf[n] = 0;

    // The process name (field 2) is in brackets and may contain spaces, so skip past the last ')'.
    const char* p = std::strrchr(buf, ')');
    if (!p) return 0;
    long utime = 0, stime = 0;
    // After ')': state ppid pgrp session tty tpgid flags minflt cminflt majflt cmajflt utime stime
    if (std::sscanf(p + 2, "%*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u %ld %ld", &utime, &stime) != 2) return 0;
    return utime + stime;
}

void CpuModule::onRender() {
    auto now = std::chrono::steady_clock::now();
    if (last_.time_since_epoch().count() == 0) {
        last_ = now;
        lastTicks_ = processTicks();
    } else if (now - last_ >= std::chrono::seconds(1)) {
        double secs = std::chrono::duration<double>(now - last_).count();
        long ticks = processTicks();
        long hz = sysconf(_SC_CLK_TCK);
        if (hz > 0 && secs > 0.0) percent_ = (ticks - lastTicks_) * 100.0 / (hz * secs);
        last_ = now;
        lastTicks_ = ticks;
    }

    char buf[32];
    std::snprintf(buf, sizeof(buf), "CPU: %.0f%%", percent_);
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

} // namespace akastra
