#pragma once
#include "core/Module.h"

namespace akastra {

// A few lines of notes pinned on screen. Saved to <data folder>/notes.txt.
class NotesModule : public Module {
public:
    NotesModule();
    void onRender() override;
    void drawSettings() override;
private:
    void save() const;
    char text_[256] = {};
};

} // namespace akastra
