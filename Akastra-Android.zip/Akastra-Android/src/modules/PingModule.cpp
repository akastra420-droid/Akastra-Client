#include "modules/PingModule.h"
#include "core/Paths.h"
#include "core/Renderer.h"
#include <imgui.h>

#include <netdb.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <vector>

namespace akastra {

namespace {

using Clock = std::chrono::steady_clock;

// Bedrock "unconnected ping" -> "unconnected pong". Returns true on a reply.
bool bedrockPing(const std::string& host, int port, int& ms, int& players, int& maxPlayers) {
    addrinfo hints{};
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    addrinfo* res = nullptr;
    const std::string portStr = std::to_string(port);
    if (getaddrinfo(host.c_str(), portStr.c_str(), &hints, &res) != 0 || !res) return false;

    int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) { freeaddrinfo(res); return false; }

    static const uint8_t magic[16] = {0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe,
                                      0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78};
    uint8_t pkt[33] = {};
    pkt[0] = 0x01;                          // unconnected ping
    std::memcpy(pkt + 9, magic, 16);        // bytes 1..8 are the time field; 25..32 the client id

    const auto t0 = Clock::now();
    bool ok = false;
    if (sendto(fd, pkt, sizeof(pkt), 0, res->ai_addr, res->ai_addrlen) == static_cast<ssize_t>(sizeof(pkt))) {
        const auto deadline = t0 + std::chrono::seconds(2);
        while (true) {
            auto left = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - Clock::now()).count();
            if (left <= 0) break;
            pollfd pfd{fd, POLLIN, 0};
            if (poll(&pfd, 1, static_cast<int>(left)) <= 0) break;
            uint8_t buf[1500];
            ssize_t n = recvfrom(fd, buf, sizeof(buf), 0, nullptr, nullptr);
            if (n <= 0) break;
            if (n >= 35 && buf[0] == 0x1C) {                 // unconnected pong
                ms = static_cast<int>(std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - t0).count());
                size_t len = (static_cast<size_t>(buf[33]) << 8) | buf[34];
                if (35 + len > static_cast<size_t>(n)) len = static_cast<size_t>(n) - 35;
                std::string info(reinterpret_cast<char*>(buf) + 35, len);   // MCPE;motd;proto;ver;players;max;...
                std::vector<std::string> f;
                size_t p = 0;
                while (true) {
                    size_t sc = info.find(';', p);
                    f.push_back(info.substr(p, sc == std::string::npos ? std::string::npos : sc - p));
                    if (sc == std::string::npos) break;
                    p = sc + 1;
                }
                players = f.size() > 4 ? std::atoi(f[4].c_str()) : -1;
                maxPlayers = f.size() > 5 ? std::atoi(f[5].c_str()) : -1;
                ok = true;
                break;
            }
        }
    }
    close(fd);
    freeaddrinfo(res);
    return ok;
}

} // namespace

PingModule::PingModule() : Module("Server Ping", "Ping and players of a server you choose") {
    x = 360.f; y = 130.f;
    std::ifstream f(dataDir() / "ping_server.txt");
    if (f) {
        std::string h, p;
        std::getline(f, h);
        std::getline(f, p);
        host_ = h;
        int v = std::atoi(p.c_str());
        if (v > 0 && v < 65536) port_ = v;
        h.copy(hostBuf_, sizeof(hostBuf_) - 1);
    }
}

PingModule::~PingModule() { stop(); }

void PingModule::onEnable() { start(); }
void PingModule::onDisable() { stop(); }

void PingModule::start() {
    if (run_) return;
    run_ = true;
    worker_ = std::thread([this] { workerLoop(); });
}

void PingModule::stop() {
    run_ = false;
    if (worker_.joinable()) worker_.join();
}

void PingModule::workerLoop() {
    while (run_) {
        std::string host;
        int port;
        {
            std::lock_guard<std::mutex> lk(mu_);
            host = host_;
            port = port_;
        }
        int ms = -1, pl = -1, mx = -1;
        if (!host.empty() && bedrockPing(host, port, ms, pl, mx)) {
            pingMs_ = ms; players_ = pl; maxPlayers_ = mx;
        } else {
            pingMs_ = -1; players_ = -1; maxPlayers_ = -1;
        }
        for (int i = 0; i < 20 && run_; ++i) std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void PingModule::saveSettings() {
    std::lock_guard<std::mutex> lk(mu_);
    std::ofstream(dataDir() / "ping_server.txt", std::ios::trunc) << host_ << "\n" << port_ << "\n";
}

void PingModule::onRender() {
    std::string host;
    {
        std::lock_guard<std::mutex> lk(mu_);
        host = host_;
    }
    if (host.empty()) {
        Renderer::get().text("Ping: set a server in the menu", x, y, 0xFFFFFFFF);
        return;
    }
    int ms = pingMs_, pl = players_, mx = maxPlayers_;
    std::string s;
    if (ms < 0) {
        s = "Ping: --";
    } else {
        s = "Ping: " + std::to_string(ms) + " ms";
        if (pl >= 0 && mx >= 0) s += " | " + std::to_string(pl) + "/" + std::to_string(mx) + " players";
    }
    uint32_t color = 0xFFFFFFFFu;
    if (ms >= 200) color = 0xFFFF5555u;
    Renderer::get().text(s, x, y, color);
}

void PingModule::drawSettings() {
    ImGui::SetNextItemWidth(220.f);
    if (ImGui::InputText("server", hostBuf_, sizeof(hostBuf_))) {
        {
            std::lock_guard<std::mutex> lk(mu_);
            host_ = hostBuf_;
        }
        saveSettings();
    }
    int port = port_;
    ImGui::SetNextItemWidth(160.f);
    if (ImGui::InputInt("port", &port) && port > 0 && port < 65536) {
        {
            std::lock_guard<std::mutex> lk(mu_);
            port_ = port;
        }
        saveSettings();
    }
}

} // namespace akastra
