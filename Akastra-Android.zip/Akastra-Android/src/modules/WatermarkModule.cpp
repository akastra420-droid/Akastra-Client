#include "modules/WatermarkModule.h"
#include "core/Renderer.h"

namespace akastra {

void WatermarkModule::onRender() {
    Renderer::get().text("Akastra Client", x, y, 0xFFE8D48A, 18.f);
}

} // namespace akastra
