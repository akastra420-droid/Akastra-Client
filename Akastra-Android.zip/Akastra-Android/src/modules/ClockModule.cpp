#include "modules/ClockModule.h"
#include "core/Renderer.h"
#include <imgui.h>
#include <ctime>
#include <cstdio>

namespace akastra {

void ClockModule::onRender() {
    std::time_t t = std::time(nullptr);
    std::tm lt{};
    localtime_r(&t, &lt);

    char buf[32];
    if (use24h_) {
        if (showSeconds_) std::snprintf(buf, sizeof(buf), "%02d:%02d:%02d", lt.tm_hour, lt.tm_min, lt.tm_sec);
        else              std::snprintf(buf, sizeof(buf), "%02d:%02d", lt.tm_hour, lt.tm_min);
    } else {
        int h12 = lt.tm_hour % 12;
        if (h12 == 0) h12 = 12;
        const char* ampm = lt.tm_hour < 12 ? "AM" : "PM";
        if (showSeconds_) std::snprintf(buf, sizeof(buf), "%d:%02d:%02d %s", h12, lt.tm_min, lt.tm_sec, ampm);
        else              std::snprintf(buf, sizeof(buf), "%d:%02d %s", h12, lt.tm_min, ampm);
    }
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

void ClockModule::drawSettings() {
    ImGui::Checkbox("24-hour", &use24h_);
    ImGui::SameLine();
    ImGui::Checkbox("seconds", &showSeconds_);
}

} // namespace akastra
