#include "modules/BatteryModule.h"
#include "core/Renderer.h"
#include <cstdio>
#include <cstring>

namespace akastra {

void BatteryModule::onRender() {
    // Refresh every 10 seconds; the value barely changes.
    auto now = std::chrono::steady_clock::now();
    if (last_.time_since_epoch().count() == 0 || now - last_ >= std::chrono::seconds(10)) {
        last_ = now;
        percent_ = -1;
        charging_ = false;

        if (FILE* f = std::fopen("/sys/class/power_supply/battery/capacity", "r")) {
            int v = -1;
            if (std::fscanf(f, "%d", &v) == 1) percent_ = v;
            std::fclose(f);
        }
        if (FILE* f = std::fopen("/sys/class/power_supply/battery/status", "r")) {
            char s[32] = {};
            if (std::fscanf(f, "%31s", s) == 1) charging_ = std::strcmp(s, "Charging") == 0;
            std::fclose(f);
        }
    }

    char buf[32];
    if (percent_ >= 0) std::snprintf(buf, sizeof(buf), "BAT: %d%%%s", percent_, charging_ ? " +" : "");
    else               std::snprintf(buf, sizeof(buf), "BAT: n/a");

    uint32_t color = 0xFFFFFFFF;
    if (percent_ >= 0 && percent_ <= 15 && !charging_) color = 0xFFFF5555;   // low battery: red
    Renderer::get().text(buf, x, y, color);
}

} // namespace akastra
