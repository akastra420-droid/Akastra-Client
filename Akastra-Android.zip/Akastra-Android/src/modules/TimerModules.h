#pragma once
#include "core/Module.h"
#include <chrono>

namespace akastra {

// Stopwatch with Start/Stop and Reset buttons in the menu.
class StopwatchModule : public Module {
public:
    StopwatchModule() : Module("Stopwatch", "Stopwatch controlled from the menu") { x = 360.f; y = 10.f; }
    void onRender() override;
    void drawSettings() override;
private:
    bool running_ = false;
    double accumulated_ = 0.0;                         // seconds before the current run
    std::chrono::steady_clock::time_point start_{};
};

// Reminds you to rest your eyes / hands every N minutes.
class BreakReminderModule : public Module {
public:
    BreakReminderModule() : Module("Break Reminder", "Reminds you to take a break") { x = 360.f; y = 40.f; }
    void onEnable() override;
    void onRender() override;
    void drawSettings() override;
private:
    int intervalMin_ = 45;
    bool alert_ = false;
    std::chrono::steady_clock::time_point start_ = std::chrono::steady_clock::now();
    std::chrono::steady_clock::time_point alertEnd_{};
};

} // namespace akastra
