#include "modules/CustomTextModule.h"
#include "core/Renderer.h"
#include <imgui.h>

namespace akastra {

void CustomTextModule::onRender() {
    Renderer::get().text(text_, x, y, 0xFFFFFFFF);
}

void CustomTextModule::drawSettings() {
    ImGui::SetNextItemWidth(220.f);
    ImGui::InputText("text", text_, sizeof(text_));
}

} // namespace akastra
