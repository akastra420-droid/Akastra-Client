#pragma once
#include "core/Module.h"
#include <chrono>
#include <string>

namespace akastra {

// Shows the phone's battery level (read from the system, no permissions asked).
class BatteryModule : public Module {
public:
    BatteryModule() : Module("Battery", "Phone battery level") { x = 140.f; y = 156.f; }
    void onRender() override;

private:
    std::chrono::steady_clock::time_point last_{};
    int percent_ = -1;          // -1 = could not be read
    bool charging_ = false;
};

} // namespace akastra
