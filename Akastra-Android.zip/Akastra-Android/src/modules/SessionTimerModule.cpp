#include "modules/SessionTimerModule.h"
#include "core/Renderer.h"
#include <cstdio>

namespace akastra {

void SessionTimerModule::onRender() {
    auto secs = std::chrono::duration_cast<std::chrono::seconds>(
                    std::chrono::steady_clock::now() - start_).count();
    char buf[32];
    std::snprintf(buf, sizeof(buf), "Session: %lld:%02lld:%02lld",
                  static_cast<long long>(secs / 3600),
                  static_cast<long long>((secs / 60) % 60),
                  static_cast<long long>(secs % 60));
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

} // namespace akastra
