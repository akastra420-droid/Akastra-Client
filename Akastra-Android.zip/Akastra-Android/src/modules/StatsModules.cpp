#include "modules/StatsModules.h"
#include "core/Paths.h"
#include "core/Renderer.h"
#include <imgui.h>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <sys/statvfs.h>

namespace akastra {

using Clock = std::chrono::steady_clock;

// ---------------------------------------------------------------- FPS Stats
void FpsStatsModule::onRender() {
    ++frames_;
    auto now = Clock::now();
    if (last_.time_since_epoch().count() == 0) last_ = now;
    if (now - last_ >= std::chrono::seconds(1)) {
        history_.push_back(frames_);
        frames_ = 0;
        last_ = now;
        if (history_.size() > 10) history_.erase(history_.begin());
    }

    char buf[64];
    if (history_.empty()) {
        std::snprintf(buf, sizeof(buf), "FPS: measuring...");
    } else {
        int mn = *std::min_element(history_.begin(), history_.end());
        int mx = *std::max_element(history_.begin(), history_.end());
        int sum = 0;
        for (int v : history_) sum += v;
        std::snprintf(buf, sizeof(buf), "FPS avg %d | min %d | max %d",
                      sum / static_cast<int>(history_.size()), mn, mx);
    }
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

// ---------------------------------------------------------------- FPS Graph
void FpsGraphModule::onRender() {
    auto now = Clock::now();
    if (last_.time_since_epoch().count() != 0) {
        ms_[head_] = std::chrono::duration<float, std::milli>(now - last_).count();
        head_ = (head_ + 1) % kSamples;
    }
    last_ = now;

    const float w = kSamples * 2.f, h = 40.f;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    dl->AddRectFilled(ImVec2(x - 2.f, y - 2.f), ImVec2(x + w + 2.f, y + h + 2.f), IM_COL32(0, 0, 0, 110), 3.f);
    for (int i = 0; i < kSamples; ++i) {
        float v = ms_[(head_ + i) % kSamples];       // oldest to newest
        if (v <= 0.f) continue;
        float bar = std::min(v / 33.3f, 1.f) * h;     // full height = 30 FPS or slower
        ImU32 col = v > 33.3f ? IM_COL32(255, 85, 85, 230) : IM_COL32(232, 212, 138, 230);
        float bx = x + i * 2.f;
        dl->AddRectFilled(ImVec2(bx, y + h - bar), ImVec2(bx + 1.5f, y + h), col);
    }
}

// -------------------------------------------------------------- Tap Counter
void TapCounterModule::onRender() {
    Renderer::get().text("Taps: " + std::to_string(taps_), x, y, 0xFFFFFFFF);
}
void TapCounterModule::drawSettings() {
    if (ImGui::Button("reset taps")) taps_ = 0;
}

// ----------------------------------------------------------------- Free RAM
void FreeRamModule::onRender() {
    auto now = Clock::now();
    if (last_.time_since_epoch().count() == 0 || now - last_ >= std::chrono::seconds(2)) {
        last_ = now;
        long totalKb = 0, availKb = 0;
        if (FILE* f = std::fopen("/proc/meminfo", "r")) {
            char line[128];
            while (std::fgets(line, sizeof(line), f)) {
                std::sscanf(line, "MemTotal: %ld kB", &totalKb);
                std::sscanf(line, "MemAvailable: %ld kB", &availKb);
            }
            std::fclose(f);
        }
        if (totalKb > 0) {
            totalGb_ = totalKb / (1024.0 * 1024.0);
            freeGb_ = availKb / (1024.0 * 1024.0);
        } else {
            totalGb_ = freeGb_ = -1.0;
        }
    }
    char buf[48];
    if (totalGb_ > 0) std::snprintf(buf, sizeof(buf), "Free RAM: %.1f / %.1f GB", freeGb_, totalGb_);
    else              std::snprintf(buf, sizeof(buf), "Free RAM: n/a");
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

// ------------------------------------------------------------------ Storage
void StorageModule::onRender() {
    auto now = Clock::now();
    if (last_.time_since_epoch().count() == 0 || now - last_ >= std::chrono::seconds(30)) {
        last_ = now;
        struct statvfs sv;
        if (statvfs(dataDir().c_str(), &sv) == 0)
            freeGb_ = static_cast<double>(sv.f_bavail) * sv.f_frsize / (1024.0 * 1024.0 * 1024.0);
        else
            freeGb_ = -1.0;
    }
    char buf[48];
    if (freeGb_ >= 0) std::snprintf(buf, sizeof(buf), "Storage: %.1f GB free", freeGb_);
    else              std::snprintf(buf, sizeof(buf), "Storage: n/a");
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

// ------------------------------------------------------------- Battery Temp
void BatteryTempModule::onRender() {
    auto now = Clock::now();
    if (last_.time_since_epoch().count() == 0 || now - last_ >= std::chrono::seconds(10)) {
        last_ = now;
        celsius_ = -1000.0;
        if (FILE* f = std::fopen("/sys/class/power_supply/battery/temp", "r")) {
            int tenths = 0;
            if (std::fscanf(f, "%d", &tenths) == 1) celsius_ = tenths / 10.0;
            std::fclose(f);
        }
    }
    char buf[32];
    if (celsius_ > -999.0) std::snprintf(buf, sizeof(buf), "Batt Temp: %.1f C", celsius_);
    else                   std::snprintf(buf, sizeof(buf), "Batt Temp: n/a");
    uint32_t color = (celsius_ >= 42.0) ? 0xFFFF5555u : 0xFFFFFFFFu;   // hot: red
    Renderer::get().text(buf, x, y, color);
}

// ------------------------------------------------------------ Device Uptime
void DeviceUptimeModule::onRender() {
    auto now = Clock::now();
    if (last_.time_since_epoch().count() == 0 || now - last_ >= std::chrono::seconds(10)) {
        last_ = now;
        secs_ = -1;
        if (FILE* f = std::fopen("/proc/uptime", "r")) {
            double up = 0.0;
            if (std::fscanf(f, "%lf", &up) == 1) secs_ = static_cast<long long>(up);
            std::fclose(f);
        }
    }
    char buf[48];
    if (secs_ >= 0) {
        long long d = secs_ / 86400, h = (secs_ / 3600) % 24, m = (secs_ / 60) % 60;
        if (d > 0) std::snprintf(buf, sizeof(buf), "Phone up: %lldd %lldh %lldm", d, h, m);
        else       std::snprintf(buf, sizeof(buf), "Phone up: %lldh %lldm", h, m);
    } else {
        std::snprintf(buf, sizeof(buf), "Phone up: n/a");
    }
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

} // namespace akastra
