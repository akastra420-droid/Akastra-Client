#pragma once
#include "core/Module.h"

namespace akastra {

class WatermarkModule : public Module {
public:
    WatermarkModule() : Module("Watermark", "Shows the Akastra Client name on screen") { setEnabled(true); }
    void onRender() override;
};

} // namespace akastra
