#include "modules/FpsModule.h"
#include "core/Renderer.h"

namespace akastra {

void FpsModule::onRender() {
    ++frames_;
    auto now = std::chrono::steady_clock::now();
    if (now - last_ >= std::chrono::seconds(1)) {
        fps_ = frames_;
        frames_ = 0;
        last_ = now;
    }
    Renderer::get().text("FPS: " + std::to_string(fps_), x, y, 0xFFFFFFFF);
}

} // namespace akastra
