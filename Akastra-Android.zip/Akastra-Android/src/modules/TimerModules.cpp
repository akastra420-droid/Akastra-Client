#include "modules/TimerModules.h"
#include "core/Renderer.h"
#include <imgui.h>
#include <cmath>
#include <cstdio>

namespace akastra {

using Clock = std::chrono::steady_clock;

// ---------------------------------------------------------------- Stopwatch
void StopwatchModule::onRender() {
    double secs = accumulated_;
    if (running_) secs += std::chrono::duration<double>(Clock::now() - start_).count();
    long long whole = static_cast<long long>(secs);
    int tenths = static_cast<int>((secs - static_cast<double>(whole)) * 10.0);
    char buf[48];
    if (whole >= 3600)
        std::snprintf(buf, sizeof(buf), "Stopwatch: %lld:%02lld:%02lld.%d", whole / 3600, (whole / 60) % 60, whole % 60, tenths);
    else
        std::snprintf(buf, sizeof(buf), "Stopwatch: %lld:%02lld.%d", whole / 60, whole % 60, tenths);
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

void StopwatchModule::drawSettings() {
    if (ImGui::Button(running_ ? "stop" : "start")) {
        if (running_) accumulated_ += std::chrono::duration<double>(Clock::now() - start_).count();
        else          start_ = Clock::now();
        running_ = !running_;
    }
    ImGui::SameLine();
    if (ImGui::Button("reset")) {
        running_ = false;
        accumulated_ = 0.0;
    }
}

// ----------------------------------------------------------- Break Reminder
void BreakReminderModule::onEnable() {
    start_ = Clock::now();
    alert_ = false;
}

void BreakReminderModule::onRender() {
    auto now = Clock::now();
    if (alert_) {
        if (now >= alertEnd_) {
            alert_ = false;
            start_ = now;
        } else {
            Renderer::get().text("Time for a break!", x, y, 0xFFE8D48A, 22.f);
            return;
        }
    }
    double elapsed = std::chrono::duration<double>(now - start_).count();
    double total = intervalMin_ * 60.0;
    if (elapsed >= total) {
        alert_ = true;
        alertEnd_ = now + std::chrono::seconds(15);
        return;
    }
    int left = static_cast<int>(std::ceil((total - elapsed) / 60.0));
    char buf[32];
    std::snprintf(buf, sizeof(buf), "Break in: %d min", left);
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

void BreakReminderModule::drawSettings() {
    ImGui::SetNextItemWidth(160.f);
    if (ImGui::SliderInt("minutes", &intervalMin_, 5, 180)) start_ = Clock::now();
}

} // namespace akastra
