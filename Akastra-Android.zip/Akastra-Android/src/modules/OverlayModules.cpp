#include "modules/OverlayModules.h"
#include <imgui.h>
#include <cmath>
#include <ctime>

namespace akastra {

namespace {
ImU32 rgba(const float rgb[3], float a) {
    return ImGui::ColorConvertFloat4ToU32(ImVec4(rgb[0], rgb[1], rgb[2], a));
}
} // namespace

// -------------------------------------------------------------- Screen Tint
void ScreenTintModule::onRender() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0.f, 0.f), ds, rgba(rgb_, alpha_));
}
void ScreenTintModule::drawSettings() {
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("strength", &alpha_, 0.f, 0.4f, "%.2f");
    ImGui::ColorEdit3("color", rgb_, ImGuiColorEditFlags_NoInputs);
}

// ----------------------------------------------------------------- Vignette
void VignetteModule::onRender() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const float e = ds.y * size_;
    const ImU32 dark = IM_COL32(0, 0, 0, static_cast<int>(strength_ * 255.f));
    const ImU32 none = IM_COL32(0, 0, 0, 0);
    dl->AddRectFilledMultiColor(ImVec2(0.f, 0.f), ImVec2(ds.x, e), dark, dark, none, none);                     // top
    dl->AddRectFilledMultiColor(ImVec2(0.f, ds.y - e), ImVec2(ds.x, ds.y), none, none, dark, dark);             // bottom
    dl->AddRectFilledMultiColor(ImVec2(0.f, 0.f), ImVec2(e, ds.y), dark, none, none, dark);                     // left
    dl->AddRectFilledMultiColor(ImVec2(ds.x - e, 0.f), ImVec2(ds.x, ds.y), none, dark, dark, none);             // right
}
void VignetteModule::drawSettings() {
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("strength", &strength_, 0.05f, 0.9f, "%.2f");
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("size", &size_, 0.05f, 0.4f, "%.2f");
}

// --------------------------------------------------------------- Letterbox
void LetterboxModule::onRender() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const float h = ds.y * amount_;
    dl->AddRectFilled(ImVec2(0.f, 0.f), ImVec2(ds.x, h), IM_COL32(0, 0, 0, 255));
    dl->AddRectFilled(ImVec2(0.f, ds.y - h), ImVec2(ds.x, ds.y), IM_COL32(0, 0, 0, 255));
}
void LetterboxModule::drawSettings() {
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("bar height", &amount_, 0.02f, 0.25f, "%.2f");
}

// -------------------------------------------------------------------- Grid
void GridModule::onRender() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const ImU32 col = IM_COL32(232, 212, 138, 90);
    for (int i = 1; i <= 2; ++i) {
        float gx = ds.x * i / 3.f, gy = ds.y * i / 3.f;
        dl->AddLine(ImVec2(gx, 0.f), ImVec2(gx, ds.y), col, 1.f);
        dl->AddLine(ImVec2(0.f, gy), ImVec2(ds.x, gy), col, 1.f);
    }
    if (centre_) {
        dl->AddLine(ImVec2(ds.x * 0.5f, 0.f), ImVec2(ds.x * 0.5f, ds.y), col, 1.f);
        dl->AddLine(ImVec2(0.f, ds.y * 0.5f), ImVec2(ds.x, ds.y * 0.5f), col, 1.f);
    }
}
void GridModule::drawSettings() {
    ImGui::Checkbox("centre lines", &centre_);
}

// ------------------------------------------------------------ Screen Border
void ScreenBorderModule::onRender() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    const float h = thickness_ * 0.5f;
    ImGui::GetBackgroundDrawList()->AddRect(ImVec2(h, h), ImVec2(ds.x - h, ds.y - h),
                                            rgba(rgb_, 0.85f), 0.f, 0, thickness_);
}
void ScreenBorderModule::drawSettings() {
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("thickness", &thickness_, 1.f, 10.f, "%.0f");
    ImGui::ColorEdit3("color", rgb_, ImGuiColorEditFlags_NoInputs);
}

// -------------------------------------------------------------- Analog Clock
void AnalogClockModule::onRender() {
    std::time_t t = std::time(nullptr);
    std::tm lt{};
    localtime_r(&t, &lt);

    const float pi = 3.14159265f;
    const ImVec2 c(x + radius_, y + radius_);
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    dl->AddCircleFilled(c, radius_, IM_COL32(0, 0, 0, 110), 48);
    dl->AddCircle(c, radius_, IM_COL32(232, 212, 138, 230), 48, 2.f);

    for (int i = 0; i < 12; ++i) {
        float a = i * pi / 6.f;
        float inner = radius_ * (i % 3 == 0 ? 0.80f : 0.88f);
        dl->AddLine(ImVec2(c.x + std::sin(a) * inner, c.y - std::cos(a) * inner),
                    ImVec2(c.x + std::sin(a) * radius_ * 0.95f, c.y - std::cos(a) * radius_ * 0.95f),
                    IM_COL32(232, 212, 138, 220), 1.5f);
    }

    auto hand = [&](float turns, float len, float width, ImU32 col) {
        float a = turns * 2.f * pi;
        dl->AddLine(c, ImVec2(c.x + std::sin(a) * radius_ * len, c.y - std::cos(a) * radius_ * len), col, width);
    };
    hand(((lt.tm_hour % 12) + lt.tm_min / 60.f) / 12.f, 0.50f, 3.f, IM_COL32(245, 232, 189, 255));
    hand((lt.tm_min + lt.tm_sec / 60.f) / 60.f,         0.75f, 2.f, IM_COL32(245, 232, 189, 255));
    hand(lt.tm_sec / 60.f,                              0.85f, 1.f, IM_COL32(255, 120, 120, 255));
}
void AnalogClockModule::drawSettings() {
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("size", &radius_, 20.f, 80.f, "%.0f");
}

} // namespace akastra
