#pragma once
#include "core/Module.h"
#include <string>

namespace akastra {

// Shows a line of text you choose.
class CustomTextModule : public Module {
public:
    CustomTextModule() : Module("Custom Text", "Shows your own text") { x = 10.f; y = 216.f; }
    void onRender() override;
    void drawSettings() override;

private:
    char text_[64] = "Akastra Client";
};

} // namespace akastra
