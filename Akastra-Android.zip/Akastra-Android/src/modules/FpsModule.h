#pragma once
#include "core/Module.h"
#include <chrono>

namespace akastra {

class FpsModule : public Module {
public:
    FpsModule() : Module("FPS", "Shows frames per second") { y = 36.f; }
    void onRender() override;

private:
    int frames_ = 0, fps_ = 0;
    std::chrono::steady_clock::time_point last_ = std::chrono::steady_clock::now();
};

} // namespace akastra
