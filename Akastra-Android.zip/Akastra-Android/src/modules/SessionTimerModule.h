#pragma once
#include "core/Module.h"
#include <chrono>

namespace akastra {

// Shows how long you've had the game open this session (H:MM:SS).
class SessionTimerModule : public Module {
public:
    SessionTimerModule() : Module("Session Timer", "Time since the client was loaded") {
        x = 120.f; y = 56.f;
    }
    void onEnable() override { start_ = std::chrono::steady_clock::now(); }
    void onRender() override;

private:
    std::chrono::steady_clock::time_point start_ = std::chrono::steady_clock::now();
};

} // namespace akastra
