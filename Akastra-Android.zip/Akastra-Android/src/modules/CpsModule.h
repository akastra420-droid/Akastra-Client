#pragma once
#include "core/Module.h"
#include <chrono>
#include <deque>

namespace akastra {

class CpsModule : public Module {
public:
    CpsModule() : Module("CPS", "Shows clicks per second") { y = 56.f; }
    void onMouse(int button, bool down) override;
    void onRender() override;

private:
    using Clock = std::chrono::steady_clock;
    std::deque<Clock::time_point> left_, right_;
    static void prune(std::deque<Clock::time_point>& d);
};

} // namespace akastra
