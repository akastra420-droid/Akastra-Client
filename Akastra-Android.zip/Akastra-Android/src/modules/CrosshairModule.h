#pragma once
#include "core/Module.h"

namespace akastra {

// Draws a custom crosshair at the centre of the screen. The game's own
// crosshair is not removed, so this is drawn on top of it. x/y act as an
// offset from the centre.
class CrosshairModule : public Module {
public:
    CrosshairModule() : Module("Crosshair", "Custom crosshair overlay") { x = 0.f; y = 0.f; }
    void onRender() override;
    void drawSettings() override;

private:
    float size_ = 8.f;       // arm length in pixels
    float thickness_ = 2.f;
    float gap_ = 4.f;        // empty space around the centre
    float rgb_[3] = {0.2f, 1.f, 0.7f};
};

} // namespace akastra
