#include "modules/NotesModule.h"
#include "core/Paths.h"
#include "core/Renderer.h"
#include <imgui.h>
#include <fstream>
#include <iterator>
#include <string>

namespace akastra {

NotesModule::NotesModule() : Module("Notes", "Your own notes on screen") {
    x = 360.f; y = 160.f;
    std::ifstream f(dataDir() / "notes.txt");
    if (f) {
        std::string s((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        s.copy(text_, sizeof(text_) - 1);
    }
}

void NotesModule::save() const {
    std::ofstream(dataDir() / "notes.txt", std::ios::trunc) << text_;
}

void NotesModule::onRender() {
    std::string s(text_);
    float ly = y;
    int lines = 0;
    size_t pos = 0;
    while (pos <= s.size() && lines < 8) {
        size_t nl = s.find('\n', pos);
        std::string line = s.substr(pos, nl == std::string::npos ? std::string::npos : nl - pos);
        if (!line.empty()) Renderer::get().text(line, x, ly, 0xFFFFFFFF);
        ly += 20.f;
        ++lines;
        if (nl == std::string::npos) break;
        pos = nl + 1;
    }
}

void NotesModule::drawSettings() {
    if (ImGui::InputTextMultiline("##notes", text_, sizeof(text_), ImVec2(260.f, 100.f))) save();
}

} // namespace akastra
