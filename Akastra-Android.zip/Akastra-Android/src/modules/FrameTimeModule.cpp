#include "modules/FrameTimeModule.h"
#include "core/Renderer.h"
#include <cstdio>

namespace akastra {

void FrameTimeModule::onRender() {
    auto now = std::chrono::steady_clock::now();
    if (last_.time_since_epoch().count() != 0) {
        float ms = std::chrono::duration<float, std::milli>(now - last_).count();
        avgMs_ = (avgMs_ == 0.f) ? ms : avgMs_ * 0.95f + ms * 0.05f;   // smooth out jitter
    }
    last_ = now;

    char buf[32];
    std::snprintf(buf, sizeof(buf), "Frame: %.1f ms", avgMs_);
    Renderer::get().text(buf, x, y, 0xFFFFFFFF);
}

} // namespace akastra
