#include "modules/CrosshairModule.h"
#include "core/Renderer.h"
#include <imgui.h>
#include <cstdint>

namespace akastra {

void CrosshairModule::onRender() {
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    float cx = ds.x * 0.5f + x;
    float cy = ds.y * 0.5f + y;

    auto to8 = [](float v) { return static_cast<uint32_t>(v * 255.f + 0.5f) & 0xFF; };
    uint32_t argb = 0xFF000000u | (to8(rgb_[0]) << 16) | (to8(rgb_[1]) << 8) | to8(rgb_[2]);

    auto& r = Renderer::get();
    float t = thickness_, h = t * 0.5f;
    r.fillRect(cx - gap_ - size_, cy - h, size_, t, argb);   // left arm
    r.fillRect(cx + gap_,         cy - h, size_, t, argb);   // right arm
    r.fillRect(cx - h, cy - gap_ - size_, t, size_, argb);   // top arm
    r.fillRect(cx - h, cy + gap_,         t, size_, argb);   // bottom arm
}

void CrosshairModule::drawSettings() {
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("size", &size_, 2.f, 30.f, "%.0f");
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("thickness", &thickness_, 1.f, 6.f, "%.0f");
    ImGui::SetNextItemWidth(160.f);
    ImGui::SliderFloat("gap", &gap_, 0.f, 20.f, "%.0f");
    ImGui::ColorEdit3("color", rgb_, ImGuiColorEditFlags_NoInputs);
}

} // namespace akastra
