#pragma once

namespace akastra::hooks {

// Hooks the game's frame presentation (eglSwapBuffers) and touch input.
// Returns false if a required hook could not be installed.
bool install();

// Helper for modules that hook game code: hook a function at a known address.
// Returns false (and logs why) on failure. Call from Module::installHooks().
bool hookAddress(const char* name, void* target, void* detour, void** original);

} // namespace akastra::hooks
