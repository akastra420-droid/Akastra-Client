#include "hooks/Hooks.h"
#include "core/Log.h"
#include "core/ModuleManager.h"
#include "core/Renderer.h"

#include <EGL/egl.h>
#include <android/input.h>
#include <dlfcn.h>
#include "dobby.h"

namespace akastra::hooks {

bool hookAddress(const char* name, void* target, void* detour, void** original) {
    if (!target) {
        log(std::string(name) + ": target address is null, hook skipped.");
        return false;
    }
    if (DobbyHook(target, reinterpret_cast<dobby_dummy_func_t>(detour),
                  reinterpret_cast<dobby_dummy_func_t*>(original)) != 0) {
        log(std::string(name) + ": DobbyHook failed.");
        return false;
    }
    log(std::string(name) + ": hooked.");
    return true;
}

// ===========================================================================
// Rendering: hook eglSwapBuffers (called once per frame by the game)
// ===========================================================================
using SwapFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
static SwapFn g_origSwap = nullptr;
static EGLContext g_ctx = EGL_NO_CONTEXT;
static bool g_failed = false;

static void renderFrame(EGLDisplay dpy, EGLSurface surf) {
    if (g_failed) return;

    EGLContext cur = eglGetCurrentContext();
    if (cur == EGL_NO_CONTEXT) return;

    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w <= 0 || h <= 0) return;

    auto& r = Renderer::get();
    if (!r.ready()) {
        if (!r.init(w, h)) {
            g_failed = true;
            log("Renderer init failed: " + r.lastError());
            return;
        }
        g_ctx = cur;
        log("Renderer initialised (OpenGL ES).");
    }
    if (cur != g_ctx) return;   // ignore any other GL context the app may use

    ModuleManager::get().pumpInput();
    r.beginFrame(w, h);
    ModuleManager::get().render();
    r.endFrame();
}

static EGLBoolean hkSwapBuffers(EGLDisplay dpy, EGLSurface surf) {
    renderFrame(dpy, surf);
    return g_origSwap(dpy, surf);
}

// ===========================================================================
// Touch: hook AInputQueue_getEvent so we see touches before the game does
// ===========================================================================
using GetEventFn = int32_t (*)(AInputQueue*, AInputEvent**);
static GetEventFn g_origGetEvent = nullptr;
static bool g_captured = false;       // true while a touch started on Akastra's UI
static bool g_loggedTouch = false;

// Returns true if Akastra owns this touch and the game must not see it.
static bool handleMotion(const AInputEvent* ev) {
    auto& r = Renderer::get();
    if (!r.ready()) return false;

    const int32_t action = AMotionEvent_getAction(ev) & AMOTION_EVENT_ACTION_MASK;
    const float s = r.scale();
    const float x = AMotionEvent_getX(ev, 0) / s;
    const float y = AMotionEvent_getY(ev, 0) / s;
    auto& mm = ModuleManager::get();

    TouchKind kind;
    switch (action) {
        case AMOTION_EVENT_ACTION_DOWN:
            // While the menu is open it is modal: it takes every touch.
            g_captured = mm.menuOpen || mm.overUi(x, y);
            kind = TouchKind::Down;
            break;
        case AMOTION_EVENT_ACTION_MOVE:
            if (!g_captured) return false;
            kind = TouchKind::Move;
            break;
        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_CANCEL:
            kind = TouchKind::Up;
            break;
        default:
            return g_captured;   // extra fingers follow the first finger's ownership
    }

    mm.pushTouch({kind, x, y, g_captured});
    const bool swallow = g_captured;
    if (kind == TouchKind::Up) g_captured = false;
    return swallow;
}

static int32_t hkGetEvent(AInputQueue* q, AInputEvent** out) {
    int32_t ret = g_origGetEvent(q, out);
    if (ret >= 0 && out && *out && AInputEvent_getType(*out) == AINPUT_EVENT_TYPE_MOTION) {
        if (!g_loggedTouch) {
            g_loggedTouch = true;
            log("First touch event seen: touch hook is working.");
        }
        if (handleMotion(*out)) {
            AInputQueue_finishEvent(q, *out, 1);   // consumed; the game never sees it
            *out = nullptr;
            return -1;
        }
    }
    return ret;
}

// ===========================================================================
bool install() {
    void* egl = dlopen("libEGL.so", RTLD_NOW);
    void* swap = egl ? dlsym(egl, "eglSwapBuffers") : nullptr;
    if (!hookAddress("eglSwapBuffers", swap, reinterpret_cast<void*>(&hkSwapBuffers),
                     reinterpret_cast<void**>(&g_origSwap))) {
        return false;
    }

    void* andr = dlopen("libandroid.so", RTLD_NOW);
    void* getEv = andr ? dlsym(andr, "AInputQueue_getEvent") : nullptr;
    if (!hookAddress("AInputQueue_getEvent", getEv, reinterpret_cast<void*>(&hkGetEvent),
                     reinterpret_cast<void**>(&g_origGetEvent))) {
        log("Touch hook failed: the HUD will draw but the menu button cannot be tapped.");
    }

    ModuleManager::get().installHooks();   // modules that hook the game
    return true;
}

} // namespace akastra::hooks
