# Akastra for Android

Akastra Client for Android (light-gold theme). Mobile version of the Akastra Bedrock client. It is a native library (`libakastra.so`) that is
loaded into the Minecraft Bedrock Android app and draws a HUD on top of the game with Dear ImGui.
It is a separate project from the Windows one; the HUD modules are shared in spirit but the
rendering, input and menu are rewritten for phones.

Target version: **1.26.60**, **Android, 64-bit ARM (arm64-v8a)** only. iOS is not supported (iOS does
not allow loading code like this without a jailbreak).

> **Status: untested.** It was written without a phone or the game to test on. Expect to need a
> round of fixes after the first run. `akastra.log` and logcat (tag `Akastra`) say what worked.

## Modules

Watermark, FPS, CPS (counts taps), Clock, Session Timer, Frame Time, Memory, Crosshair.
Keystrokes is not included because phones have no keyboard.

## Using it

- A small **A** button floats on the left edge of the screen. **Tap it to open the menu**, tap **X** to close.
- While the menu is open it takes all touches, so the game doesn't react to them.
- In the menu: tick a module to turn it on, drag the x/y numbers to move it, drag empty space to scroll.
- Settings are saved to `Android/data/<minecraft package>/files/Akastra/config.json` when the menu closes.
- Log file: `Android/data/<minecraft package>/files/Akastra/akastra.log`.

## Building (no Android tools needed)

GitHub builds it for you:

1. Create a free GitHub account and a new repository.
2. Upload the contents of this folder (including the hidden `.github` folder) to the repository.
3. Open the **Actions** tab, pick **Build Android library**, and wait for it to finish
   (it also runs automatically on upload).
4. Open the finished run and download the **libakastra** artifact. It contains `libakastra.so`.

To build locally instead you need the Android NDK (r25 or newer) and CMake:

```
cmake -B build -S . -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static \
      -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

## Getting it into the game

The library has to be loaded by the game process. `libakastra.so` starts itself as soon as it is
loaded (no extra setup). The usual ways to load a library are:

- an app/launcher that supports loading extra `.so` libraries into Minecraft, or
- patching your own copy of the Minecraft APK to load `libakastra.so` at startup and re-signing it.

I can't verify which launchers or tools work with 1.26.60, so check that yours supports library
loading for the current version. Only modify your own copy of the game, and keep to cosmetic/HUD
features. Realms and some servers don't allow client modifications.

## How it works

1. `eglSwapBuffers` (called once per frame) is hooked with Dobby. On the first frame ImGui is
   initialised on the game's OpenGL ES context, and every frame the HUD and menu are drawn.
2. `AInputQueue_getEvent` is hooked to see touches before the game. Touches that start on the A
   button (or any touch while the menu is open) are given to ImGui and hidden from the game.
3. Everything is laid out in logical pixels and scaled to the phone's resolution.

## Known limitations

- **OpenGL ES only.** If the game is using Vulkan, nothing will be drawn. If `akastra.log` shows
  "Renderer initialised" but you see nothing, this is the likely cause; look for a graphics API
  option in the game's video settings.
- **Touch path is an assumption.** If the log never shows "First touch event seen", the game gets
  touches in a different way (for example through GameActivity) and the button can't be tapped.
- If you start a touch on the A button while another finger is already on the screen, the game
  may briefly see an unmatched pointer event.
- No signatures are used, so this should survive game updates, but there are no game-specific
  modules (coordinates, armor status, fullbright, view model) for the same reason as on PC.
  `hooks::hookAddress` is there if you ever get addresses for them.
- Not affiliated with Mojang, Microsoft or Flarial.

## Extra modules (added)

All of these are overlay-only: they draw on top of the game and need no game addresses.

FPS Stats, FPS Graph, Tap Counter, Free RAM, Storage, Battery Temp, Device Uptime, Stopwatch,
Break Reminder, Screen Tint, Vignette, Letterbox, Grid, Screen Border, Analog Clock, Notes,
Server Ping, plus Date, Battery, CPU and Custom Text. They all appear in the same menu (tap the
**A** button) and are off by default.

- **Server Ping**: type a Bedrock server address and port in the menu. Shows ping and player count.
  Saved to `ping_server.txt` in the Akastra data folder.
- **Notes**: saved to `notes.txt` in the Akastra data folder.
- Battery, Battery Temp and similar readouts show `n/a` if your Android version blocks reading them.
- Overlays (Tint, Vignette, Letterbox, Grid, Border) draw above the HUD text.
- Module-specific sliders and colors are not saved yet; only on/off and position are.
- Modules that need the game's internals (View Model, Fullbright, Item Physics, Zoom, etc.) are
  NOT included: they need addresses from the game binary.
